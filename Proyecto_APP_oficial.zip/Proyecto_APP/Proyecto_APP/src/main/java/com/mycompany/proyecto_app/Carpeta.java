/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_app;

import javax.swing.JDialog;

/**
 *
 * @author PC111
 */
public class Carpeta extends JDialog {
    private String nombre;
    private String texto;
    private String ruta;
    
    public Carpeta(String nombre, String ruta, String texto){
        this.nombre = nombre;
        this.ruta = ruta;
        this.texto = texto;
    }
    
    public String getnombre(){
        return nombre;
    }
    
    public String gettexto(){
        return texto;
    }
    
    public String getruta(){
        return ruta;
    }
}

